package com.example.producto_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
